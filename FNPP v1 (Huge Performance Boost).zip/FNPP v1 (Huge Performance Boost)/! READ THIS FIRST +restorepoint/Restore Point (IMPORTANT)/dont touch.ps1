# Automated System Restore Script
# Run this script as Administrator

# Function to check if system restore is enabled
function Check-SystemRestoreEnabled {
    $status = Get-ComputerRestorePoint -ErrorAction SilentlyContinue
    if (!$status) {
        Write-Output "System Restore is not enabled or no restore points are available."
        return $false
    }
    return $true
}

# Function to start the system restore process
function Start-SystemRestore {
    param (
        [int]$RestorePointID
    )

    Write-Output "Starting system restore to Restore Point ID: $RestorePointID..."
    $result = ([WmiClass]"root\default:SystemRestore").Restore($RestorePointID)

    if ($result -eq 0) {
        Write-Output "System restore initiated successfully. The system will restart shortly."
    } elseif ($result -eq 1058) {
        Write-Output "System Restore is disabled on this system."
    } else {
        Write-Output "Failed to start system restore. Error code: $result"
    }
}

# Main script logic
if (-not (Check-SystemRestoreEnabled)) {
    Write-Output "Exiting script. Enable System Restore or create a restore point before trying again."
    pause
    exit
}

# List available restore points
Write-Output "Fetching available restore points..."
$restorePoints = Get-ComputerRestorePoint

if ($restorePoints.Count -eq 0) {
    Write-Output "No restore points found. Exiting script."
    pause
    exit
}

# Display restore points
Write-Output "Available Restore Points:"
$restorePoints | ForEach-Object {
    Write-Output "ID: $($_.SequenceNumber) - Description: $($_.Description) - Type: $($_.EventType)"
}

# Select the most recent restore point
$latestRestorePoint = $restorePoints | Sort-Object -Property CreationTime -Descending | Select-Object -First 1

Write-Output "Automatically selecting the most recent restore point: ID $($latestRestorePoint.SequenceNumber) - $($latestRestorePoint.Description)"

# Confirm the restore
Write-Output "Are you sure you want to proceed with the system restore? (Y/N)"
$choice = Read-Host "Type Y to proceed or N to cancel"

if ($choice -eq 'Y') {
    Start-SystemRestore -RestorePointID $latestRestorePoint.SequenceNumber
} else {
    Write-Output "System restore canceled by user."
    exit
}
